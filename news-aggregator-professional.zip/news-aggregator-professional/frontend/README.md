# Frontend (Vite + React + TypeScript + Tailwind)

## Setup (development)
1. cd frontend
2. npm install
3. Copy `.env.example` to `.env` and update VITE_API_URL if needed.
4. npm run dev

Dev server: http://localhost:5173
